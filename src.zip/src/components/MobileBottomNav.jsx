"use client";

import "@/styles/MobileBottomNav.css";

// const QUALIFICATIONS = [
//   "10th Pass",
//   "12th Pass",
//   "Diploma",
//   "Graduate",
//   "Post Graduate",
//   "Other",
// ];

const MobileBottomNav = () => {
  // const [open, setOpen] = useState(false);
  // const [form, setForm] = useState({
  //   name: "",
  //   phone: "",
  //   email: "",
  //   qualification: "",
  // });
  // const [submitting, setSubmitting] = useState(false);
  // const [done, setDone] = useState(false);
  // const [error, setError] = useState("");

  // const handleChange = (e) =>
  //   setForm({ ...form, [e.target.name]: e.target.value });

  // const handleSubmit = async (e) => {
  //   e.preventDefault();
  //   setSubmitting(true);
  //   setError("");
  //   try {
  //     await API.post("/enquiries", form);
  //     setDone(true);
  //     setForm({ name: "", phone: "", email: "", qualification: "" });
  //     setTimeout(() => {
  //       setDone(false);
  //       setOpen(false);
  //     }, 2500);
  //   } catch {
  //     setError("Something went wrong. Please try again.");
  //   }
  //   setSubmitting(false);
  // };

  return (
    <>
      {/* Enquiry Popup */}
      {/* {open && (
        <div
          className="enquiry-overlay"
          onClick={(e) => e.target === e.currentTarget && setOpen(false)}
        >
          <div className="enquiry-modal">
            <button className="enquiry-close" onClick={() => setOpen(false)}>
              ✕
            </button>

            {done ? (
              <div className="enquiry-success">
                <div className="enquiry-success-icon">✓</div>
                <h3>Thank You!</h3>
                <p>We'll get back to you shortly.</p>
              </div>
            ) : (
              <>
                <div className="enquiry-modal-header">
                  <h2>Apply Now</h2>
                  <p>Fill in your details and we'll reach out to you.</p>
                </div>

                <form onSubmit={handleSubmit} className="enquiry-form">
                  <div className="enquiry-field">
                    <label>Full Name *</label>
                    <input
                      name="name"
                      value={form.name}
                      onChange={handleChange}
                      required
                      placeholder="Your full name"
                    />
                  </div>
                  <div className="enquiry-field">
                    <label>Phone Number *</label>
                    <input
                      name="phone"
                      type="tel"
                      value={form.phone}
                      onChange={handleChange}
                      required
                      placeholder="+91 XXXXX XXXXX"
                    />
                  </div>
                  <div className="enquiry-field">
                    <label>Email Address *</label>
                    <input
                      name="email"
                      type="email"
                      value={form.email}
                      onChange={handleChange}
                      required
                      placeholder="you@email.com"
                    />
                  </div>
                  <div className="enquiry-field">
                    <label>Highest Qualification *</label>
                    <select
                      name="qualification"
                      value={form.qualification}
                      onChange={handleChange}
                      required
                    >
                      <option value="">Select qualification</option>
                      {QUALIFICATIONS.map((q) => (
                        <option key={q}>{q}</option>
                      ))}
                    </select>
                  </div>

                  {error && <p className="enquiry-error">{error}</p>}

                  <button
                    type="submit"
                    disabled={submitting}
                    className="enquiry-submit"
                  >
                    {submitting ? "Submitting..." : "Submit Enquiry"}
                  </button>
                </form>
              </>
            )}
          </div>
        </div>
      )} */}

      {/* Bottom Nav Bar */}
      <div className="mobile-bottom-nav">
        <a
          href="https://admission.miu.edu.in"
          target="_blank"
          rel="noopener noreferrer"
          className="nav-item apply-btn-mobile"
          aria-label="Apply Now"
          style={{ display: "flex", alignItems: "center", gap: "2px" }}
        >
          Apply (UG/PG)
        </a>

        <a
          href="https://student.miu.edu.in"
          target="_blank"
          rel="noopener noreferrer"
          className="nav-item"
          aria-label="Student Portal"
        >
          <svg
            // xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="lucide lucide-user-key-icon lucide-user-key"
          >
            <path d="M20 11v6" />
            <path d="M20 13h2" />
            <path d="M3 21v-2a4 4 0 0 1 4-4h6a4 4 0 0 1 2.072.578" />
            <circle cx="10" cy="7" r="4" />
            <circle cx="20" cy="19" r="2" />
          </svg>
        </a>

        <a href="tel:+919319727766" className="nav-item" aria-label="Call Us">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l2.27-2.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
          </svg>
        </a>

        <a
          href="https://wa.me/919319727766"
          target="_blank"
          rel="noopener noreferrer"
          className="nav-item"
          aria-label="WhatsApp"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 360 362"
            width="100%"
            height="100%"
          >
            <path
              fill="#25D366"
              fillRule="evenodd"
              d="M307.546 52.566C273.709 18.684 228.706.017 180.756 0 81.951 0 1.538 80.404 1.504 179.235c-.017 31.594 8.242 62.432 23.928 89.609L0 361.736l95.024-24.925c26.179 14.285 55.659 21.805 85.655 21.814h.077c98.788 0 179.21-80.413 179.244-179.244.017-47.898-18.608-92.926-52.454-126.807v-.008Zm-126.79 275.788h-.06c-26.73-.008-52.952-7.194-75.831-20.765l-5.44-3.231-56.391 14.791 15.05-54.981-3.542-5.638c-14.912-23.721-22.793-51.139-22.776-79.286.035-82.14 66.867-148.973 149.051-148.973 39.793.017 77.198 15.53 105.328 43.695 28.131 28.157 43.61 65.596 43.593 105.398-.035 82.149-66.867 148.982-148.982 148.982v.008Zm81.719-111.577c-4.478-2.243-26.497-13.073-30.606-14.568-4.108-1.496-7.09-2.243-10.073 2.243-2.982 4.487-11.568 14.577-14.181 17.559-2.613 2.991-5.226 3.361-9.704 1.117-4.477-2.243-18.908-6.97-36.02-22.226-13.313-11.878-22.304-26.54-24.916-31.027-2.613-4.486-.275-6.91 1.959-9.136 2.011-2.011 4.478-5.234 6.721-7.847 2.244-2.613 2.983-4.486 4.478-7.469 1.496-2.991.748-5.603-.369-7.847-1.118-2.243-10.073-24.289-13.812-33.253-3.636-8.732-7.331-7.546-10.073-7.692-2.613-.13-5.595-.155-8.586-.155-2.991 0-7.839 1.118-11.947 5.604-4.108 4.486-15.677 15.324-15.677 37.361s16.047 43.344 18.29 46.335c2.243 2.991 31.585 48.225 76.51 67.632 10.684 4.615 19.029 7.374 25.535 9.437 10.727 3.412 20.49 2.931 28.208 1.779 8.604-1.289 26.498-10.838 30.228-21.298 3.73-10.46 3.73-19.433 2.613-21.298-1.117-1.865-4.108-2.991-8.586-5.234l.008-.017Z"
            />
          </svg>
        </a>
      </div>
    </>
  );
};

export default MobileBottomNav;
