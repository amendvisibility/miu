import Hero from "@/components/Hero";
import HeroTest from "@/components/HeroTest";
import StructuredData from "@/components/StructuredData";
import "@/styles/HomePage.css";
import dynamic from "next/dynamic";

const Stats = dynamic(() => import("@/components/Stats"));
const CampusLife = dynamic(() => import("@/components/CampusLife"));
const Placements = dynamic(() => import("@/components/Placements"));
const Ecosystem = dynamic(() => import("@/components/Ecosystem"));
const NewsSlider = dynamic(() => import("@/components/NewsSlider"));
const FAQ = dynamic(() => import("@/components/FAQ"));

export const metadata = {
  title: "Manipur International University | Best University in Manipur",
  description:
    "Manipur International University is a leading university in Manipur offering UG, PG, Diploma, and Ph.D. programs with quality education, expert faculty, and admissions open for 2026-27.",
  keywords:
    "Manipur International University, MIU Imphal, university in Manipur, MIU India, engineering college Manipur, management college Imphal",
  alternates: {
    canonical: "https://miu.edu.in/",
  },
  openGraph: {
    title: "Manipur International University | MIU Imphal",
    description:
      "Premier university in Imphal, Manipur offering quality higher education",
    url: "https://miu.edu.in/",
    siteName: "Manipur International University",
    type: "website",
  },
};

async function getHomepageData() {
  try {
    const res = await fetch(
      `${process.env.NEXT_PUBLIC_BASE_URL}/api/homepage`,
      {
        next: { revalidate: 300 },
      },
    );

    if (!res.ok) return null;

    return res.json();
  } catch (error) {
    console.error("Homepage data fetch failed:", error);
    return null;
  }
}

export default async function Home() {
  const results = await getHomepageData();

  return (
    <main>
      <Hero data={results?.hero} />
      {/* <Marquee /> */}
      <HeroTest />
      {/* <Spotlight data={results?.spotlight} /> */}
      {/* <CTA /> */}
      <Stats />
      <CampusLife data={results?.campus} />
      <Ecosystem data={results?.ecosystem?.cards} />
      <Placements data={results?.placements} />
      <NewsSlider blogs={results?.blogs} />
      <FAQ faqs={results?.faqs} />
      <StructuredData />
    </main>
  );
}
